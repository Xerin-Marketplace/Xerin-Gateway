# Phase 3 Task 1 — Inventory Reservation Engine

Adds durable per-order-item stock reservations, expiry, atomic commit/release, payment integration, and a cleanup command.

## Install
Back up and copy the included files into the project, then copy the migration and test.

## Validate before migration
```bash
python -m compileall api
python -c "from api.main import api; print('Phase 3 Task 1 import successful')"
python -m pytest -m "not integration" -v
python -m alembic heads
```

## Migrate
```bash
python -m alembic upgrade head
python -m alembic current
```
Expected head: `phase3_task1_inventory_reservations`.

## Cleanup expired reservations
Run periodically (for example once per minute with cron/systemd):
```bash
python -m api.scripts.release_expired_reservations
```

## Environment
Optional:
```env
INVENTORY_RESERVATION_MINUTES=30
```

## Important behavior
- Checkout creates one reservation per order item under row locks.
- Payment initiation rejects expired/incomplete reservations.
- Successful payment commits reservations and deducts physical stock exactly once.
- Failed or cancelled provider callbacks release stock and cancel the pending order.
- Sellers cannot manually modify `reserved_quantity`.
