# Phase 3 Task 2 — Marketplace Commission Engine

Adds hierarchical commission rules (product > seller > category > global), immutable per-order-item commission snapshots, an idempotent marketplace ledger, admin commission endpoints, and seller earnings summary.

## Install
Copy the included files over the backend, copy the migration and test, remove the extracted package directory before pytest, then run:

```bash
python -m compileall api
python -m alembic heads
python -m alembic upgrade head
python -m api.seed_permissions
python -m pytest -m "not integration" -v
```

Expected Alembic head: `p3_commission_engine`.
