# Phase 3 Task 4 — Refund and Reversal Engine

Adds full/partial item refunds, lifecycle review, commission and seller-wallet reversal, seller debt recovery, idempotency, inventory restocking audit, permissions, API routes, migration, and contract tests.

Migration chain: `p3_seller_wallets -> p3_refund_engine`.
