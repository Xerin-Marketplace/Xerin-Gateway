# Phase Two Task 2 — Checkout Shipping and Shipments

This package is built from the uploaded backend after `phase2_task1_shipping`.

## Adds
- Mandatory server-validated `shipping_rate_id` at checkout.
- Server-side shipping cost and delivery-date calculation.
- Order shipping snapshot fields.
- One shipment per seller per paid order.
- Shipment items and immutable tracking history.
- Buyer tracking, seller-owned shipment management, and admin management.
- Controlled shipment state transitions.
- Idempotent shipment creation during payment callbacks.

## Installation
Back up the listed files, then copy the package files over the project. Copy the migration to `alembic/versions/`.

Run:
```bash
python -m compileall api
python -m pytest -m "not integration" -v
python -m alembic upgrade head
python -m alembic current
python -m api.seed_permissions
```

Expected Alembic head: `phase2_task2_shipments`.

## Important API change
`POST /api/v1/orders` now requires both:
```json
{"shipping_address_id":"UUID", "shipping_rate_id":"UUID"}
```
The frontend must first call `POST /api/v1/shipping/quote`, display available options, and submit only the selected `rate_id`. The backend recalculates the amount and never trusts a frontend-supplied shipping price.
